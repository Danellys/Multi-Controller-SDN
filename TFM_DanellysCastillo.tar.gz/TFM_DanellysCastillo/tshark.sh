#!/bin/bash
sudo tshark -i any -O openflow_v5 -Y 'openflow_v5.type ==5' -e frame.time -Tfields  -l > OFEvents.txt
