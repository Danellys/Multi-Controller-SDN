import os
import datetime
from datetime import timedelta
import inspect
import GUI
import variables
def date(QuantityCtrl):
    i=1
    filename = inspect.getframeinfo(inspect.currentframe()).filename
    path = os.path.dirname(os.path.abspath(filename))
    x = int(QuantityCtrl.get())
    alldates = list()
    while (i<=x):
        os.system("gnome-terminal --working-directory=" +path+ " -- sudo rm -f Topology.Events*")
        os.system("gnome-terminal --working-directory=" + path + " -- sudo rm  -f Log*")
        with open('scriptEvents'+str(i)+'.sh', "w") as f:
            f.write("#!/bin/bash")
            f.write("\n")
            f.write('sudo lxc-attach -n ONOS'+str(i)+' -e sudo cat /opt/onos1/apache-karaf-3.0.8/data/log/karaf.log >>Log'+str(i)+'.txt')
        os.system("gnome-terminal --working-directory=" +path+ " -- bash ./scriptEvents"+str(i)+".sh")
        os.system("gnome-terminal --working-directory=" + path + " -- cat TopologyEvents"+str(i)+".txt")
        open('TopologyEvents'+str(i)+'.txt','w').writelines([line for line in open('Log'+str(i)+'.txt') if 'TopologyManager' in line])

        with open('TopologyEvents'+str(i)+'.txt') as f:
            n =i-1
            line = f.readlines()
            lastline = line[-1]
            lastdate = lastline.split('|')
            lastdate=lastdate[0]
            lastdate=lastdate.replace("-", ",")
            lastdate=lastdate.replace(":", ",")
            lastdate = lastdate.replace(" ", ",")
            lastdate=lastdate[:-1]
            lastdate=lastdate+'000'
            lastdate1=datetime.datetime.strptime(lastdate, '%Y,%m,%d,%H,%M,%S,%f')
            alldates.append(lastdate1)
            alldates.sort()
            i = i + 1
    print(alldates[-x])
    with open('OFEvents.txt') as f:
        line = f.readlines()
        lastrequest = line[-x]
        print (lastrequest)
        lastrequest=lastrequest.replace(" ", ",")
        lastrequest=lastrequest.replace(".", ",")
        lastrequest =lastrequest.replace(":", ",")
        lastrequest=lastrequest[:3]+lastrequest[4:6]+lastrequest[7:-8]
        if (len(lastrequest))==26:
            lastrequest=lastrequest[:4]+'0'+lastrequest[4:]
        print (lastrequest)
        lastrequestdate=datetime.datetime.strptime(lastrequest,'%b,%d,%Y,%H,%M,%S,%f')
        print(lastrequestdate)
        delta = lastdate1 -lastrequestdate + timedelta(hours=1)
        print(delta.total_seconds())
        GUI.latencia=delta.total_seconds
        #latencia=delta
def launchwireshark(QuantityCtrl):
    filename = inspect.getframeinfo(inspect.currentframe()).filename
    path = os.path.dirname(os.path.abspath(filename))
    x = int(QuantityCtrl.get())
    os.system("gnome-terminal --working-directory=" + path + " -- bash ./tshark.sh ")