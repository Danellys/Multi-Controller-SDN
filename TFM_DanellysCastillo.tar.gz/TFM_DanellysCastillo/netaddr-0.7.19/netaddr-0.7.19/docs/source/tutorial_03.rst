================================
Tutorial 3: Working with IP sets
================================

.. include:: ../../tutorials/2.x/ip/sets.txt
