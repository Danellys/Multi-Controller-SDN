============================
What's new in netaddr 0.7.19
============================

.. include:: ../../CHANGELOG
