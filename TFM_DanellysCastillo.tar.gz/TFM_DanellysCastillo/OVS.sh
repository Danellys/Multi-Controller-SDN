#!/bin/bash
sudo ovsdb-tool show-log > OVSEvents.txt
