def init():
    global latencia
    latencia='lala'