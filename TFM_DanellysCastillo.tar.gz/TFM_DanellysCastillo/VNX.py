#Importando paquetes necesarios
import Errores
import SwitchXML
import HostXML
import Controller
import SubnetXML
import ComandosVNX
def editxml(ControllerType, QuantityCtrl, switch, host, ip_address,TopologyType):
    #Se crea una variable x que tendrá el valor de la cantidad de controladores definidas por el usuario
    x = int(QuantityCtrl.get())
    #Se verifica que las variables switch y host sean números enteros
    print(switch)
    print(host)
    # Se abre el archivo scriptescenario.xml y se agrega su contenido al archivo escenario.xml
    with open("scriptescenario.xml") as f:
        lines = f.readlines()
        with open("escenario.xml", "w") as f1:
            f1.writelines(lines)
    if (switch >0 and host >0):
        #Se verifica que switch sea mayor que cero, se crean nuevas variables y ciclos de modo que permitan crear un archivo xml
        #en el que los switches se puedan comunicar a todas controladoras existentes y además conectarse con otros switches
        if switch >0:
            controllers=SwitchXML.create_switch(switch, ip_address,x,TopologyType)
            if host > 0:
              HostXML.create_host(switch, host)
        #Se crea otro ciclo para definir la parte del xml referente a la cantidad de controladores y sus respecivas direcciones IP
        #Se define también el comando cluster.sh que se ejecutará en el boot y permitirá crear el clúster

    Controller.create_cluster(ControllerType, ip_address, x)
        #Una vez la información de los host, switch y controladores ha sido definida se agregan estás ultimas lineas que definen la subred y cierran el archivo xml
    SubnetXML.create_subnet(ip_address)


