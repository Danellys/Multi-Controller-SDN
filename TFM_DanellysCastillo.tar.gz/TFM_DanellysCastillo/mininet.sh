#!/bin/bash
sudo  mn --topo=linear,3 --controller=remote,ip=10.1.0.5  --switch ovs,protocols=OpenFlow13

