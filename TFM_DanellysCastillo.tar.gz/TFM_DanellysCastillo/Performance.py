
import PerformanceError
import RunTest

def performancetest(QFlows, QFpr, IP_test1, ControllerType):
    #Verificación de Errores
    flows = PerformanceError.flowerror(QFlows)
    fpr = PerformanceError.fprerror(QFpr)
    IP_test=PerformanceError.check_iptest(IP_test1)
    #Ejecución de Pruebas
    RunTest.testflow(flows,fpr, IP_test, ControllerType)